using UnityEngine;

public class GeradorColetavel : MonoBehaviour
{
    public GameObject prefabColetavel; 
    public float tempoGeracao = 2.0f;  
    public Transform pontoSpawn;       
    
    [Header("Configurações de Aleatoriedade")]
    public bool usarAleatoriedade = true;
    public float varianciaX = 2.0f; 
    public float varianciaY = 1.0f; 

    private float cronometro;

    void Start()
    {
        cronometro = tempoGeracao;
    }

    void Update()
    {
        cronometro -= Time.deltaTime;

        if (cronometro <= 0f)
        {
            Vector3 posicaoFinal = pontoSpawn.position;

            if (usarAleatoriedade)
            {
                float offsetX = Random.Range(-varianciaX, varianciaX);
                float offsetY = Random.Range(-varianciaY, varianciaY);
                
                posicaoFinal += new Vector3(offsetX, offsetY, 0);
            }

            Instantiate(prefabColetavel, posicaoFinal, Quaternion.identity);
            
            cronometro = tempoGeracao;
        }
    }
}