using UnityEngine;
using TMPro;

public class PontosUI : MonoBehaviour
{
    public static PontosUI Instance;
    private int pontuacaoTotal;
    public TMP_Text textoPontuacaoUI;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    void Start()
    {
        pontuacaoTotal = 0;
        AtualizarUI();
    }

    public void AdicionarPontos(int pontos)
    {
        pontuacaoTotal += pontos;
        AtualizarUI();
    }

    public void ResetarPontos()
    {
        pontuacaoTotal = 0;
        AtualizarUI();
    }

    private void AtualizarUI()
    {
        if (textoPontuacaoUI != null)
            textoPontuacaoUI.text = "Pontos: " + pontuacaoTotal;
    }
}